# DropShadow Press & Editorial Kit

## One-Line Pitch

DropShadow is a survival maze game for iPhone where players guide a living drop through deadly rooms, collect mass, use abilities, and escape before the Shadow catches them.

## Short Description

DropShadow is a fast survival maze game where every second costs mass. Guide a living drop through dangerous rooms, read the maze, use abilities, and reach the exit before the Shadow catches up.

## Editorial Angle

DropShadow is built around one simple idea: what if running out of time also meant running out of yourself? The player’s drop loses and gains mass throughout each run, turning movement, risk, recovery, and survival into one readable system. The Shadow adds constant pressure, making every hesitation feel dangerous without making the game hard to understand.

## Gameplay Pillars

- Movement under pressure.
- Mass as survival.
- Readable danger.
- Personal survival style.
- Daily ritual.

## Fact Sheet

- Title: DropShadow
- Platform: iPhone
- Genre: Survival Maze / Action
- Release window: 2026
- Developer: Alessandro Nobile
- Website: dropshadow.it
- Contact: hello@dropshadow.it
- Monetization: Free
- Languages: English

## Developer Note

DropShadow started from a simple feeling: what if the player was not just running out of time, but running out of themselves? The game turns that idea into a fast maze experience where every move has a cost, every hesitation matters, and every escape feels like it happened one second later than it should have.

